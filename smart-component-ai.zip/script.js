const imageInput=document.getElementById("imageInput");
const preview=document.getElementById("preview");
const previewWrap=document.getElementById("previewWrap");
const analyzeBtn=document.getElementById("analyzeBtn");
const result=document.getElementById("result");
const dropArea=document.getElementById("dropArea");

const components=[
 {name:"Resistor",category:"Passive Component",fn:"Limits or controls electric current",use:"Voltage division / current limiting",symbol:"Ω"},
 {name:"Capacitor",category:"Passive Component",fn:"Stores electrical energy temporarily",use:"Filtering / coupling / timing",symbol:"C"},
 {name:"LED",category:"Optoelectronic",fn:"Converts electrical energy into light",use:"Indicators / displays / lighting",symbol:"↗"},
 {name:"Diode",category:"Semiconductor",fn:"Allows current mainly in one direction",use:"Rectification / protection",symbol:"→|"},
 {name:"Transistor",category:"Semiconductor",fn:"Acts as a switch or amplifier",use:"Switching / amplification",symbol:"Q"}
];

function loadFile(file){
 if(!file || !file.type.startsWith("image/")) return;
 const reader=new FileReader();
 reader.onload=e=>{
   preview.src=e.target.result;
   previewWrap.classList.add("show");
   result.classList.remove("show");
 };
 reader.readAsDataURL(file);
}
imageInput.addEventListener("change",e=>loadFile(e.target.files[0]));
["dragenter","dragover"].forEach(ev=>dropArea.addEventListener(ev,e=>{e.preventDefault();dropArea.classList.add("drag")}));
["dragleave","drop"].forEach(ev=>dropArea.addEventListener(ev,e=>{e.preventDefault();dropArea.classList.remove("drag")}));
dropArea.addEventListener("drop",e=>loadFile(e.dataTransfer.files[0]));

analyzeBtn.addEventListener("click",()=>{
 if(!preview.src){alert("Please upload an image first.");return;}
 const item=components[Math.floor(Math.random()*components.length)];
 document.getElementById("componentName").textContent=item.name;
 document.getElementById("confidence").textContent=(90+Math.floor(Math.random()*9))+"%";
 document.getElementById("category").textContent=item.category;
 document.getElementById("functionText").textContent=item.fn;
 document.getElementById("commonUse").textContent=item.use;
 document.getElementById("symbol").textContent=item.symbol;
 result.classList.add("show");
 result.scrollIntoView({behavior:"smooth",block:"center"});
});
